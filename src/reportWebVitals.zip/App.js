import './App.css';
import RightComponent from './components/RightComponent';


function App() {
  return (
    <div className="App"
      style={{
        position:"relative"
      }}
    >
      <RightComponent/>
    </div>
  );
}

export default App;
